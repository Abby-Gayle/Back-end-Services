package task;

public class Task {
	//variables to hold data of id name and description
	private final String taskId;
	private String name, description;
	
	//constructor
	public Task(String taskId, String name, String description) {
		if(taskId == null||taskId.length() > 10) {
			throw new IllegalArgumentException("Invalid Id");
		}
		this.taskId = taskId;
		
		if(name == null || name.length() > 20) {
			throw new IllegalArgumentException("Invalid name");
		}
		this.name = name;
		
		if(description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid description");
		}
		this.description = description;
		
	}
	//set the name
	public void setName(String name) {
		if(name == null || name.length() > 20) {
			throw new IllegalArgumentException("Invalid name");
		}
		this.name = name;
	}
	//sets the descrip[tion
	public void setDescription(String description) {
		if(description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid description");
		}
		this.description = description;
	}
	
	//gets the id
	public String getTaskId() {
		return taskId;
	}
	
	//gets the name
	public String getName() {
		return name;
	}
	
	//gets the description
	public String getDescription() {
		return description;
	}
}
