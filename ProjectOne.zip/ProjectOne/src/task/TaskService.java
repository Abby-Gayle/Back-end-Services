
package task;
import java.util.Map;
import java.util.HashMap;

public class TaskService {
	//HashMap for string keys and Task values
	private Map<String, Task> tasks = new HashMap<>();
	
	public void addTasks(Task task) {
			if(tasks.containsKey(task.getTaskId())) {	//id exist
				throw new IllegalArgumentException("Id Exists");
			}
		tasks.put(task.getTaskId(), task);	//adds new task
	}
	
	//deletes data
	public void deleteTask(String taskID) {
		if(!tasks.containsKey(taskID)) {
			throw new IllegalArgumentException("Id not found");
		}
		tasks.remove(taskID);
	}
	
	//updates data from tasks
	public void updateTask(String taskID, String name, String description) {
			if(tasks.get(taskID) != null) {		//
				tasks.get(taskID).setName(name);				//updates data
				tasks.get(taskID).setDescription(description);
			}
	}
	
	//checks tasks run well
	Task checkTask(String taskId) {
		return tasks.get(taskId);
	}
}
