package task;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TaskTest {

	@Test
	void testTask() {
		Task task = new Task("626", "Stich", "Alien Life-Form");
		assertEquals("626", task.getTaskId());
		assertEquals("Stich", task.getName());
		assertEquals("Alien Life-Form", task.getDescription());
	}
	
	@Test
	void nullIdTask() {
		assertThrows(IllegalArgumentException.class, () -> 
		new Task(null, "Name", "A persons name"));
	}
	
	@Test
	void nullNameTask() {
		assertThrows(IllegalArgumentException.class, () -> 
		new Task("6245", null, "A persons name"));
	}
	
	@Test
	void nullDescTask() {
		assertThrows(IllegalArgumentException.class, () -> 
		new Task("456", "Name", null));
	}
	
	@Test
	void IdTooLong() {
		assertThrows(IllegalArgumentException.class, () -> 
		new Task("4554654654656", "Name", "A persons name"));
	}
	
	@Test
	void nameTooLong() {
		assertThrows(IllegalArgumentException.class, () -> 
		new Task("45", "Nameskajfhksahafkdhjakiuwiwrfae", "A persons name"));
	}
	
	@Test
	void descTooLong() {
		assertThrows(IllegalArgumentException.class, () -> 
		new Task("45546", "Name", "The English Longest Word: pneumonoultramicroscopicsilicovolcanoconiosis"));
	}


	@Test
	void setNameTest(){
		Task task = new Task("626", "Stich", "Alien Life-Form");
		task.setName("Angel");
		assertEquals("Angel", task.getName());
	}
	
	@Test
	void setNameTooLongTest(){
		Task task = new Task("626", "Stich", "Alien Life-Form");
		assertThrows(IllegalArgumentException.class, () ->
		task.setName("Angeldfhksajfhiuehiwaflweauhuilaehf"));
	}
	
	@Test
	void setNameNullTest(){
		Task task = new Task("626", "Stich", "Alien Life-Form");
		assertThrows(IllegalArgumentException.class, () ->
		task.setName(null));
	}
	
	@Test
	void setDescriptionTest(){
		Task task = new Task("626", "Stich", "Alien Life-Form");
		task.setDescription("Hello there");
		assertEquals("Hello there", task.getDescription());
	}
	
	@Test
	void setDescriptionNullTest(){
		Task task = new Task("626", "Stich", "Alien Life-Form");
		assertThrows(IllegalArgumentException.class, () ->
		task.setDescription(null));
	}

	@Test
	void setDescriptionTooLongTest(){
		Task task = new Task("626", "Stich", "Alien Life-Form");
		assertThrows(IllegalArgumentException.class, () ->
		task.setDescription("Angeldfhksajfhiuehiwaflweauhufgkjasdgfsugdfksgfjsdghfhkahgkfygsfkgdjfhskfkhsdgfsdajdhjilaehf"));
	}
}
