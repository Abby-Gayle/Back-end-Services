package task;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TaskServiceTest {

	@Test
	void addTaskTest() {
		TaskService service = new TaskService();
		Task task = new Task("626", "Stich", "Alien Life-Form");
		service.addTasks(task);
		assertNotNull(service.checkTask("626"));
	}
	
	@Test
	void addTaskDifIdTest() {
		TaskService service = new TaskService();
		Task task = new Task("626", "Stich", "Alien Life-Form");
		service.addTasks(task);
		assertNull(service.checkTask("456"));
	}
	
	
	@Test
	void deleteTaskTest() {
		TaskService service = new TaskService();
		Task task = new Task("626", "Stich", "Alien Life-Form");
		service.addTasks(task);
		assertNotNull(service.checkTask("626"));
		service.deleteTask("626");
		assertNull(service.checkTask("626"));
	}
	
	@Test 
	void updateTaskTest(){
		TaskService service = new TaskService();
		Task task = new Task("626", "Stich", "Alien Life-Form");
		service.addTasks(task);
		assertEquals("626", task.getTaskId());
		service.updateTask("626", "Angel", "Alien Life-Form");
		assertEquals("626", task.getTaskId());
		assertEquals("Angel", task.getName());
	}
	
	@Test
	void duplicateTaskIdTest() {
		TaskService service = new TaskService();
		Task task1 = new Task("626", "Stich", "Alien Life-Form");
		Task task2 = new Task("626", "Angel", "Alien Life-Form");
		service.addTasks(task1);
		assertThrows(IllegalArgumentException.class, () ->
		{
			service.addTasks(task2);
		});
	}

	
	@Test
	void updateTaskWrongIDInputTest() {
	    TaskService service = new TaskService();
	    Task task = new Task("626", "Stich", "Alien Life-Form");
	    service.addTasks(task);
	    service.updateTask("456", "Angel", "fdhsgj");
	    assertEquals("Stich", task.getName());
	    assertEquals("Alien Life-Form", task.getDescription());
	}
	
	@Test
	void deleteTaskWrongIdTest() {
	    TaskService service = new TaskService();
	    Task task = new Task("626", "Stich", "Alien Life-Form");
	    service.addTasks(task);
	    assertThrows(IllegalArgumentException.class, () ->{
	    	service.deleteTask("456");
	    });
	}
	
	@Test
	void addTaskSameIdTest() {
	    TaskService service = new TaskService();
	    Task task1 = new Task("626", "Stich", "Alien Life-Form");
	    Task task2 = new Task("626", "Angel", "Alien Life-Form");
	    service.addTasks(task1);
	    assertThrows(IllegalArgumentException.class, () -> {
	    	service.addTasks(task2);
	    });
	    
	}
	
	@Test
	void addTaskNotSameIdTest() {
		TaskService service = new TaskService();
		Task task1 = new Task("626", "Stich", "Alien Life-Form");
		service.addTasks(task1);
		assertNotNull(service.checkTask("626"));
		Task task2 = new Task("456", "dhsajdja", "adfhsdj");
		service.addTasks(task2);
		assertNotNull(service.checkTask("456"));
			
	}

}
