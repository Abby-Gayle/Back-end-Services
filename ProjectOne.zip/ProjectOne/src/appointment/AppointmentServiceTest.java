package appointment;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

class AppointmentServiceTest {

	@Test
	void addAppointmentTest() {
		AppointmentService service = new AppointmentService();
		Date futureDate = new Date(System.currentTimeMillis() + 86400000);
		Appointment appointment = new Appointment("123", futureDate, "This is a test");
		service.addAppointment(appointment);
		assertNotNull(service.verifyData("123"));
	}
	@Test
	void duplicateIdAddAppointmentTest() {
		AppointmentService service = new AppointmentService();
		Date futureDate = new Date(System.currentTimeMillis() + 86400000);
		Appointment appointment = new Appointment("123", futureDate, "This is a test");
		Appointment appointment2 = new Appointment("123", futureDate, "This is a test, bob");
		service.addAppointment(appointment);
		assertThrows(IllegalArgumentException.class, () ->{
			service.addAppointment(appointment2);
		});
	}
	
	@Test
	void deleteAppointmentTest() {
		AppointmentService service = new AppointmentService();
		Date futureDate = new Date(System.currentTimeMillis() + 86400000);
		Appointment appointment = new Appointment("123", futureDate, "This is a test");
		service.addAppointment(appointment);
		service.deleteAppointment("123");
		assertNull(service.verifyData("123"));
	}
	
	@Test
	void unknownIdDeleteAppointmentTest() {
		AppointmentService service = new AppointmentService();
		Date futureDate = new Date(System.currentTimeMillis() + 86400000);
		Appointment appointment = new Appointment("123", futureDate, "This is a test");
		service.addAppointment(appointment);
		assertThrows(IllegalArgumentException.class, () ->{
			service.deleteAppointment("245");
		});
		
	}

}

