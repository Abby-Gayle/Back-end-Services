package appointment;
import java.util.HashMap;
import java.util.Map;
public class AppointmentService {
	//HashMap for sting keys and Appointment values
	Map<String, Appointment> appointments = new HashMap<>();
	
	public void addAppointment(Appointment appointment){
		String id = appointment.getAppointmentId();		//get the id "key"
		
		if(appointments.containsKey(id)) {				//check if the key is in table
			throw new IllegalArgumentException("Id already exists");
		}				
		appointments.put(id, appointment);	//adds the id and information
	}
	
	void deleteAppointment(String id) {
		
		if(!appointments.containsKey(id)) {				//check if the key is not in table
			throw new IllegalArgumentException("Id doesn't exist");
		}				
		appointments.remove(id);	//deletes information with that id
	}
	
	Appointment verifyData(String id) {
		return appointments.get(id);	//gets the id and information with it 
	}
}
