package appointment;
import java.util.Date;
public class Appointment {
	private final String appointmentId;		//holds the appointment ids
	private Date appointmentDate;			//holds the dates
	private String appointmentDesc;			//holds the description
	
	public Appointment(String id, Date date, String description) {	
		if(id == null || id.length() > 10) {							//checks id can't be null or higher then 10 digits
			throw new IllegalArgumentException("Invalid id");
		}
		this.appointmentId = id;										//sets id to private id
		
		if(date == null || date.before(new Date())) {					//checks date cant be null or cant be past dates
			throw new IllegalArgumentException("Invalid date");
		}
		this.appointmentDate = date;									//sets date to private date
		
		if(description == null || description.length() > 50) {			//checks descriptions can't be null or longer then 50 char
			throw new IllegalArgumentException("Invalid description");
		}
		this.appointmentDesc = description;								//sets desc to private desc
	}
	
	//SETTERS check validation and set information required to the private dates and descriptions
	public void setAppointmentDate(Date date) {
		if(date == null || date.before(new Date())) {
			throw new IllegalArgumentException("Invalid date");
		}
		this.appointmentDate = date;
	}
	
	public void setAppointmentDesc(String description) {
		if(description == null || description.length() > 50 ) {
			throw new IllegalArgumentException("Invalid description");
		}
		this.appointmentDesc = description;
	}
	
	//GETTERS these return the ids, dates, and description
	public String getAppointmentId() {
		return appointmentId;
	}
	
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	
	public String getAppointmentDesc() {
		return appointmentDesc;
	}
	
}
