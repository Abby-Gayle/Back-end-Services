package appointment;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AppointmentTest {

	//ID TESTs
	@Test
	void validIdTest() {
		Date futureDate = new Date(System.currentTimeMillis() + 864000000);
		Appointment appointment = new Appointment("123456", futureDate, "dhfshfgsa");
		assertEquals("123456", appointment.getAppointmentId());
	}
	
	@Test
	void lengthIdTest() {
		Date futureDate = new Date(System.currentTimeMillis() + 86400000);
		assertThrows(IllegalArgumentException.class, ()
				-> {
					new Appointment("12345678910", futureDate, "ajshdfkjskf");
				});
	}
	
	@Test
	void nullIdTest() {
		Date futureDate = new Date(System.currentTimeMillis() + 864000000);
		assertThrows(IllegalArgumentException.class, () ->{
			new Appointment(null, futureDate, "sjdhdaksfhd");
		});
	}
	
	//DATE TESTs
	@Test
	void validDateTest() {
		Date futureDate = new Date(System.currentTimeMillis() + 864000000);
		Appointment appointment = new Appointment ("123456", futureDate, "sfhgdhfks");
		assertEquals(futureDate, appointment.getAppointmentDate());
	}
	
	@Test
	void setDateTest() {
		Date futureDate = new Date(System.currentTimeMillis() + 864000000);
		Appointment appointment = new Appointment ("123", futureDate, "sjkdhakdjh");
		appointment.setAppointmentDate(futureDate);
		assertEquals(futureDate, appointment.getAppointmentDate());
	}
	
	@Test
	void nullDateTest() {
		assertThrows(IllegalArgumentException.class, () ->{
			new Appointment("123", null, "ashdgsaj");
		});
	}
	
	@Test
	void setNullDateTest() {
		Date futureDate = new Date(System.currentTimeMillis() + 864000000);
		Appointment appointment = new Appointment ("123", futureDate, "skdfhask");
		assertThrows(IllegalArgumentException.class, () -> {
			appointment.setAppointmentDate(null);
		});
		
	}
	
	@Test
	void pastSetDateTest() {
		Date futureDate = new Date(System.currentTimeMillis() + 864000000);
		Date pastDate = new Date(System.currentTimeMillis() - 864000000);
		Appointment appointment = new Appointment ("123", futureDate, "asjdgaj");
		assertThrows(IllegalArgumentException.class, () ->{
			appointment.setAppointmentDate(pastDate);
		});
	}
	
	@Test
	void pastDateTest() {
		Date pastDate = new Date(System.currentTimeMillis() - 864000000);
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("123", pastDate, "sdfhaskdhs");
		});
	}
	
	//TEST DESCRIPTIONS
	@Test
	void validDescTest() {
		Date futureDate = new Date(System.currentTimeMillis() + 864000000);
		Appointment appointment = new Appointment("123456", futureDate, "dhfshfgsa");
		assertEquals("dhfshfgsa", appointment.getAppointmentDesc());
	}
	
	@Test
	void setDescTest() {
		Date futureDate = new Date(System.currentTimeMillis() + 864000000);
		Appointment appointment = new Appointment ("123", futureDate, "sjkdhakdjh");
		appointment.setAppointmentDesc("This is a test");
		assertEquals("This is a test", appointment.getAppointmentDesc());
	}
	
	@Test
	void nullDescTest() {
		Date futureDate = new Date(System.currentTimeMillis() + 864000000);
		assertThrows(IllegalArgumentException.class, () ->{
			new Appointment("123", futureDate, null);
		});
	}
	
	@Test
	void setNullDescTest() {
		Date futureDate = new Date(System.currentTimeMillis() + 864000000);
		Appointment appointment = new Appointment ("123", futureDate, "skdfhask");
		assertThrows(IllegalArgumentException.class, () -> {
			appointment.setAppointmentDesc(null);
		});
	}
	
	@Test
	void lengthDescTest() {
		Date futureDate = new Date(System.currentTimeMillis() + 864000000);
		assertThrows(IllegalArgumentException.class, () ->{
			new Appointment("123", futureDate, "Longest Word in English: pneumonoultramicroscopicsilicovolcanoconiosis");
		});
	}
	
	@Test
	void lengthSetDescTest() {
		Date futureDate = new Date(System.currentTimeMillis() + 864000000);
		Appointment appointment = new Appointment ("123", futureDate, "asjdgaj");
		assertThrows(IllegalArgumentException.class, () ->{
			appointment.setAppointmentDesc("Longest Word in English: pneumonoultramicroscopicsilicovolcanoconiosis");
		});
	}

}
